<?php
//include('dbip-client.class.php');
require_once ('GoogleMapsTimeZone.php');
define('API_KEY', 'AIzaSyD3mRdAbkhUCkRiQ8HGpure2Ifs7RpDQ0o');
use Illuminate\Support\Facades\Route;
use App\Models\Task;
use Illuminate\Http\Request;
use imelgrat\GoogleMapsTimeZone\GoogleMapsTimeZone;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


//$db = new PDO("mysql:host=localhost;dbname=airschool", "root", "");
$ip = $_SERVER['REMOTE_ADDR'];
 
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    }

// Lookup IP address information
//$addrInfo = DBIP\Address::lookup($ipAddress);
$user_ip = $ip;
$url = "http://ipinfo.io/".$user_ip;

$ip_info = json_decode(file_get_contents($url));

$loc = $ip_info->loc ?? '';
$loc_array = explode(',',$loc);
$lat = $loc_array[0] ?? '';
$long = $loc_array[1]  ?? '';
$timezone_object = new GoogleMapsTimeZone($lat, $long, GoogleMapsTimeZone::FORMAT_JSON);
 
// Set Google API key
$timezone_object->setApiKey(API_KEY);
 
// Perform query 
$timezone_data = $timezone_object->queryTimeZone();


Route::get('/', function () {
    $tasks = Task::all();
    return view('tasks.index',compact('tasks','timezone_data'));
});
Route::post('/store', function (Request $request) {
    $tasks = new Task;

    $tasks->task_name = $request->task_name;
    $tasks->status = 'pending';
    $tasks->save();
    return redirect('/');
});
