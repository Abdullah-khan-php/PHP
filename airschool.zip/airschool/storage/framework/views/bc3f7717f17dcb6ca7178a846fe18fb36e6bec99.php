<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/bootstrap.min.css')); ?>" media="screen" />
    <title>Air School</title>
    <style>
    h1 {
        margin-top: 5px;
        text-align: center;
    }
    .table td, .table th {
  border: 1px solid #ddd;
  padding: 8px;
}
    </style>
</head>

<body>
    <div class="container">
        <h1>Welcome to AirSchool</h1>
        <form action="<?php echo e(URL::to('/store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-sm-6">
                    <label>Task Name </label>
                    <input type="text" placeholder="enter task name" class="form-control" name="task_name" id="task_name">
                </div>
            </div>
            <br>
            <div class="row">
            <div class="col-sm-6">
                <input type="submit" value="Add" class="btn btn-info">
            </div>
            </div>
        </form>
        <br>
        <table class="table .table-striped">
            <thead>
                <th>id</th>
                <th>Task Name</th>
                <th>Status</th>
                <th>Time</th>
            </thead>
            <tbody>
                <?php if(count($tasks) > 0): ?>
                <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($task->id); ?></td>
                    <td><?php echo e($task->task_name); ?></td>
                    <td><?php echo e($task->status); ?></td>
                    <td><?php echo e(Carbon\Carbon::parse($task->created_at)->format('M d, Y h:i:s')); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>

</html><?php /**PATH C:\xampp\htdocs\airschool\resources\views/tasks/index.blade.php ENDPATH**/ ?>