<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="{{ URL::asset('css/bootstrap.min.css') }}" media="screen" />
    <title>Air School</title>
    <style>
    h1 {
        margin-top: 5px;
        text-align: center;
    }
    .table td, .table th {
  border: 1px solid #ddd;
  padding: 8px;
}
    </style>
</head>

<body>
    <div class="container">
        <h1>Welcome to AirSchool</h1>
        <form action="{{URL::to('/store')}}" method="POST">
        @csrf
            <div class="row">
                <div class="col-sm-6">
                    <label>Task Name </label>
                    <input type="text" placeholder="enter task name" class="form-control" name="task_name" id="task_name">
                </div>
            </div>
            <br>
            <div class="row">
            <div class="col-sm-6">
                <input type="submit" value="Add" class="btn btn-info">
            </div>
            </div>
        </form>
        <br>
        <table class="table .table-striped">
            <thead>
                <th>id</th>
                <th>Task Name</th>
                <th>Status</th>
                <th>Database Time</th>
                <th>Timeone Data Time</th>
            </thead>
            <tbody>
                @if(count($tasks) > 0)
                @foreach($tasks as $task)
                <tr>
                    <td>{{$task->id}}</td>
                    <td>{{$task->task_name}}</td>
                    <td>{{$task->status}}</td>
                    <td>{{Carbon\Carbon::parse($task->created_at)->format('M d, Y h:i:s')}}</td>
                    <td>{{$timezone_data}}</td>
                </tr>
                @endforeach
                @endif
            </tbody>
        </table>
    </div>
</body>

</html>
<?php 
// $fmt = new IntlDateFormatter("fa_IR@calendar=persian", IntlDateFormatter::FULL, IntlDateFormatter::FULL, 'Asia/Tehran', IntlDateFormatter::TRADITIONAL);
// echo $fmt->format(time());
?>